package dio.spring.secutiry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DioSpringSecutiryApplication {

	public static void main(String[] args) {
		SpringApplication.run(DioSpringSecutiryApplication.class, args);
	}

}
