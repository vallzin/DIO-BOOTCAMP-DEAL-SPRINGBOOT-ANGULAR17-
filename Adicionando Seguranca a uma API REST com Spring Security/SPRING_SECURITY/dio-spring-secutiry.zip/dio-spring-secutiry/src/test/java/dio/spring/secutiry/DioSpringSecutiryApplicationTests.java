package dio.spring.secutiry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DioSpringSecutiryApplicationTests {

	@Test
	void contextLoads() {
	}

}
