package dio.my_first.web_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstProjectApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
